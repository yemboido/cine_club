<div class="menu">
	<div class="card">
		<div class="card-header">
			<h2>Actions</h2>
		</div>
		<div class="card-content">
			<a href="<?php echo BASE_URL . 'admin/enregistrerSalle.php' ?>">Enregistrer Salle</a>
			<a href="<?php echo BASE_URL . 'admin/modifierSalle.php' ?>">Modifier/supprimer Salle</a>
			
	
		</div>
	</div>
</div>