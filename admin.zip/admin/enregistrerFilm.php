<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


 <form method="post" action="">
          
            <strong>NUMERO</strong>
            <input  type="text" name="num"><br><br>
             <strong>TITRE</strong>
            <input  type="text" name="Prenom"><br><br>
            <strong>GENRE</strong>
            <input  type="text" name="genre"><br><br>
            <strong>ANNEE</strong>
            <input  type="text" name="annee"><br><br>
            <strong>DUREE</strong>
            <input type="num" name="duree"><br><br>
            <strong>BUDGET</strong>
            <input type="password" name="bud"><br><br>
            <input type="submit" class="long" value="VALIDE" name="valide">

        
    </form>

</body>
</html>